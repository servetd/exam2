<?php

session_start();

// Güvenlik: Sadece admin bu işlemi yapabilir
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../../index.php?page=login');
    exit;
}

$pdo = require __DIR__ . '/../../config/database.php';

$redirect_url = '../../index.php?page=manage_topics';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $subject_id = $_POST['subject_id'] ?? null;

    // Add subject_id to redirect URL to stay on the same page
    if ($subject_id) {
        $redirect_url .= '&subject_id=' . $subject_id;
    }

    if ($action === 'add') {
        $parent_id = isset($_POST['parent_id']) && $_POST['parent_id'] !== '' ? $_POST['parent_id'] : null;
        $name = trim($_POST['name'] ?? '');
        $importance = $_POST['importance'] ?? 1;

        if (!empty($name) && !empty($subject_id)) {
            try {
                // Get the next sequence number based on parent_id
                if ($parent_id === null) {
                    // Root topic - get max sequence from root topics
                    $seq_stmt = $pdo->prepare("SELECT COALESCE(MAX(sequence), 0) as max_seq FROM topics WHERE subject_id = :subject_id AND parent_id IS NULL");
                    $seq_stmt->execute(['subject_id' => $subject_id]);
                } else {
                    // Child topic - get max sequence from this parent's children
                    $seq_stmt = $pdo->prepare("SELECT COALESCE(MAX(sequence), 0) as max_seq FROM topics WHERE parent_id = :parent_id");
                    $seq_stmt->execute(['parent_id' => $parent_id]);
                }
                $result = $seq_stmt->fetch();
                $next_sequence = ($result['max_seq'] ?? 0) + 1;

                $stmt = $pdo->prepare(
                    "INSERT INTO topics (subject_id, parent_id, name, importance, sequence) VALUES (:subject_id, :parent_id, :name, :importance, :sequence)"
                );
                $stmt->execute([
                    'subject_id' => $subject_id,
                    'parent_id' => $parent_id,
                    'name' => $name,
                    'importance' => $importance,
                    'sequence' => $next_sequence
                ]);
                $_SESSION['success'] = 'Konu başarıyla eklendi.';
            } catch (PDOException $e) {
                $_SESSION['error'] = 'Konu eklenirken bir hata oluştu: ' . $e->getMessage();
            }
        }
    } elseif ($action === 'delete') {
        $topic_id = $_POST['topic_id'] ?? null;

        if ($topic_id && $subject_id) {
            try {
                // Check if topic has children
                $check_stmt = $pdo->prepare("SELECT COUNT(*) as count FROM topics WHERE parent_id = :topic_id");
                $check_stmt->execute(['topic_id' => $topic_id]);
                $result = $check_stmt->fetch();

                if ($result['count'] > 0) {
                    $_SESSION['error'] = 'Bu konunun alt konuları vardır. Önce alt konuları silmelisiniz.';
                } else {
                    $stmt = $pdo->prepare("DELETE FROM topics WHERE id = :topic_id AND subject_id = :subject_id");
                    $stmt->execute([
                        'topic_id' => $topic_id,
                        'subject_id' => $subject_id
                    ]);
                    $_SESSION['success'] = 'Konu başarıyla silindi.';
                }
            } catch (PDOException $e) {
                $_SESSION['error'] = 'Konu silinirken bir hata oluştu: ' . $e->getMessage();
            }
        }
    }
}

// İşlem sonrası konu yönetimi sayfasına geri dön
header('Location: ' . $redirect_url);
exit;
