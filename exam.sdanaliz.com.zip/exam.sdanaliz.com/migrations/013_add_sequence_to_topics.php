<?php

$pdo = require __DIR__ . '/../config/database.php';

$sql = <<<'SQL'
ALTER TABLE topics ADD COLUMN sequence INTEGER DEFAULT 0;
SQL;

try {
    $pdo->exec($sql);
    echo "'sequence' sütunu 'topics' tablosuna başarıyla eklendi.\n";
} catch (PDOException $e) {
    if (strpos($e->getMessage(), 'duplicate column name') !== false) {
        echo "'sequence' sütunu zaten mevcut.\n";
    } else {
        die("Sütun ekleme hatası: " . $e->getMessage());
    }
}
