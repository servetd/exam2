<?php
// Fetch all subjects for the dropdown
$subjects_stmt = $pdo->query("SELECT * FROM subjects ORDER BY name");
$subjects = $subjects_stmt->fetchAll();

$selected_subject_id = $_GET['subject_id'] ?? null;
$all_topics = [];

if ($selected_subject_id) {
    // Get parent topic names - order by root topics first, then by parent, then by sequence
    $topics_stmt = $pdo->prepare("SELECT t.*, p.name as parent_name FROM topics t LEFT JOIN topics p ON t.parent_id = p.id WHERE t.subject_id = :subject_id ORDER BY CASE WHEN t.parent_id IS NULL THEN 0 ELSE 1 END, COALESCE(t.parent_id, t.id), t.sequence ASC");
    $topics_stmt->execute(['subject_id' => $selected_subject_id]);
    $all_topics = $topics_stmt->fetchAll();
}

// Function to get importance stars
function get_importance_stars($importance) {
    return str_repeat('★', $importance) . str_repeat('☆', 5 - $importance);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Topics - Exam System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if (isset($_SESSION['warning'])): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <?php echo $_SESSION['warning']; unset($_SESSION['warning']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php require __DIR__ . '/../../includes/navbar.php'; ?>

    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1>Manage Topics and Subtopics</h1>
            <a href="index.php?page=dashboard" class="btn btn-secondary">Return to Dashboard</a>
        </div>

        <!-- Subject Selection Form -->
        <div class="card mb-4">
            <div class="card-header">Subject Selection</div>
            <div class="card-body">
                <form method="GET">
                    <input type="hidden" name="page" value="manage_topics">
                    <div class="input-group">
                        <select name="subject_id" class="form-select" required>
                            <option value="">Please select a subject...</option>
                            <?php foreach ($subjects as $subject): ?>
                                <option value="<?php echo $subject['id']; ?>" <?php echo ($selected_subject_id == $subject['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($subject['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <button class="btn btn-primary" type="submit">Show Topics</button>
                    </div>
                </form>
            </div>
        </div>

        <?php if ($selected_subject_id): ?>
            <!-- Add Topic Form -->
            <div class="card mb-4">
                <div class="card-header">Add New Topic</div>
                <div class="card-body">
                    <form action="src/admin/topic_action.php" method="POST" class="row g-3">
                        <input type="hidden" name="subject_id" value="<?php echo $selected_subject_id; ?>">
                        <div class="col-md-4">
                            <label for="name" class="form-label">Topic Name</label>
                            <input type="text" class="form-control" id="name" name="name" placeholder="e.g., Main Topic" required>
                        </div>
                        <div class="col-md-4">
                            <label for="parent_id" class="form-label">Parent Topic (Optional)</label>
                            <select class="form-select" id="parent_id" name="parent_id">
                                <option value="">-- No Parent (Main Topic) --</option>
                                <?php
                                $parent_topics = array_filter($all_topics, fn($t) => $t['parent_id'] === NULL);
                                foreach ($parent_topics as $parent):
                                ?>
                                    <option value="<?php echo $parent['id']; ?>">
                                        <?php echo htmlspecialchars($parent['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label for="importance" class="form-label">Importance</label>
                            <select class="form-select" id="importance" name="importance" required>
                                <option value="1">1 ★☆☆☆☆</option>
                                <option value="2">2 ★★☆☆☆</option>
                                <option value="3" selected>3 ★★★☆☆</option>
                                <option value="4">4 ★★★★☆</option>
                                <option value="5">5 ★★★★★</option>
                            </select>
                        </div>
                        <div class="col-md-2 d-flex align-items-end">
                            <button type="submit" name="action" value="add" class="btn btn-primary w-100">Add Topic</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Topic Import Form -->
            <div class="card mb-4">
                <div class="card-header">Import Topics from Excel/CSV</div>
                <div class="card-body">
                    <form action="src/admin/topic_import_action.php" method="POST" enctype="multipart/form-data" class="row g-3">
                        <input type="hidden" name="subject_id" value="<?php echo $selected_subject_id; ?>">
                        <div class="col-md-6">
                            <label for="topicFile" class="form-label">Select File (Excel or CSV)</label>
                            <input class="form-control" type="file" id="topicFile" name="topic_file" accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" required>
                            <small class="text-muted">Format: Topic Name | Parent Topic (optional) | Importance (1-5)</small>
                        </div>
                        <div class="col-md-6 d-flex align-items-end">
                            <button type="submit" class="btn btn-success w-100">Upload and Import</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Topics Table -->
            <div class="card">
                <div class="card-header">Topics List</div>
                <div class="card-body">
                    <?php if (empty($all_topics)): ?>
                        <p class="text-center text-muted">No topics found for this subject.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover table-striped">
                                <thead class="table-light">
                                <tr>
                                    <th style="width: 70%;">Topic Name</th>
                                    <th style="width: 15%;">Importance</th>
                                    <th style="width: 15%;">Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                $topics_by_parent = [];
                                foreach ($all_topics as $topic) {
                                    $topics_by_parent[$topic['parent_id']][] = $topic;
                                }

                                function display_topics($parent_id, $topics_by_parent, $selected_subject_id, $level = 0) {
                                    if (!isset($topics_by_parent[$parent_id])) {
                                        return;
                                    }

                                    foreach ($topics_by_parent[$parent_id] as $topic) {
                                        $is_main = $level === 0;
                                        $indentation = str_repeat('&nbsp;&nbsp;&nbsp;&nbsp;', $level);
                                        ?>
                                        <tr <?php echo $is_main ? 'style="background-color: #f8f9fa; font-weight: 500;"' : ''; ?>>
                                            <td>
                                                <?php
                                                echo $indentation;
                                                if (!$is_main) {
                                                    echo '↳ ';
                                                }
                                                echo htmlspecialchars($topic['name']);
                                                ?>
                                            </td>
                                            <td>
                                                <span class="badge" style="background-color: #ffc107; color: #000;">
                                                    <?php echo get_importance_stars($topic['importance']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <form action="src/admin/topic_action.php" method="POST" style="display: inline;">
                                                    <input type="hidden" name="subject_id" value="<?php echo $selected_subject_id; ?>">
                                                    <input type="hidden" name="topic_id" value="<?php echo $topic['id']; ?>">
                                                    <button type="submit" name="action" value="delete" class="btn btn-sm btn-danger" onclick="return confirm('Bu konuyu silmek istediğinizden emin misiniz?')">Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php
                                        // Recursively display children
                                        display_topics($topic['id'], $topics_by_parent, $selected_subject_id, $level + 1);
                                    }
                                }

                                // Start displaying from root topics (parent_id is NULL)
                                display_topics(NULL, $topics_by_parent, $selected_subject_id);
                                ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
</body>
</html>
