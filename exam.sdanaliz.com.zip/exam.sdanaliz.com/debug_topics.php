<?php
$pdo = require __DIR__ . '/config/database.php';

$subject_id = 3;
$topics_stmt = $pdo->prepare("SELECT t.*, p.name as parent_name FROM topics t LEFT JOIN topics p ON t.parent_id = p.id WHERE t.subject_id = :subject_id ORDER BY CASE WHEN t.parent_id IS NULL THEN 0 ELSE 1 END, COALESCE(t.parent_id, t.id), t.sequence ASC");
$topics_stmt->execute(['subject_id' => $subject_id]);
$all_topics = $topics_stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<pre>";
echo "Total topics: " . count($all_topics) . "\n\n";
foreach ($all_topics as $topic) {
    echo "ID: {$topic['id']}, Name: {$topic['name']}, Parent ID: " . ($topic['parent_id'] ?? 'NULL') . ", Type: " . gettype($topic['parent_id']) . "\n";
}
echo "</pre>";
?>
